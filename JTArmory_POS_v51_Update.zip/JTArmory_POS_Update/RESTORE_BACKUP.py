"""Offline backup restore tool. Never run while the POS is open."""
from pathlib import Path
import sqlite3, shutil, datetime, sys
ROOT=Path(__file__).resolve().parent
DB=ROOT/'jtarmory_pos.sqlite3'
BACKUPS=ROOT/'backups'
files=sorted(BACKUPS.glob('jtarmory_*.sqlite3'),reverse=True) if BACKUPS.exists() else []
print('JTARMORY - OFFLINE DATABASE RESTORE\n')
if not files:
    print('No backups found in the backups folder.');input('Press Enter to close...');sys.exit(1)
print('CLOSE ALL POS WINDOWS AND STOP THE START_POS.BAT PROCESS FIRST.\n')
for i,f in enumerate(files,1):print(str(i)+'. '+f.name)
choice=input('Enter the backup number to restore (blank to cancel): ').strip()
if not choice:sys.exit(0)
try:chosen=files[int(choice)-1];assert int(choice)>0
except (ValueError,IndexError,AssertionError):print('Invalid selection');sys.exit(1)
with sqlite3.connect(chosen) as c:
    if c.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise RuntimeError('Backup integrity check failed')
confirm=input('Type RESTORE to replace the current database (a safety copy will be made): ')
if confirm!='RESTORE':print('Cancelled.');sys.exit(0)
if DB.exists():
    try:
        c=sqlite3.connect('file:'+str(DB).replace('\\','/')+'?mode=ro',uri=True,timeout=0.1)
        c.execute('BEGIN EXCLUSIVE')
        c.close()
    except sqlite3.OperationalError:
        raise RuntimeError('Database is busy. Exit the POS completely before restoring.')
    stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    safety=BACKUPS/('PRE_RESTORE_'+stamp+'.sqlite3')
    with sqlite3.connect(DB) as old,sqlite3.connect(safety) as out:old.backup(out)
with sqlite3.connect(chosen) as old,sqlite3.connect(DB) as out:old.backup(out)
print('Restored '+chosen.name+' successfully. Start POS now.')
input('Press Enter to close...')
