@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (py -3 RESTORE_BACKUP.py) else (python RESTORE_BACKUP.py)
pause
