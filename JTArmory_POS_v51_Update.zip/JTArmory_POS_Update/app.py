"""JTArmory local POS. Python 3.10+, standard library only."""
import csv, io, json, os, re, sqlite3, threading, webbrowser, uuid, shutil, subprocess, sys, time
from datetime import datetime, date, timedelta
from decimal import Decimal, ROUND_HALF_UP, InvalidOperation
from html import unescape
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import parse_qs, quote, urlparse, urlencode, urljoin
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent
DB = ROOT / 'jtarmory_pos.sqlite3'
HOST, PORT = '127.0.0.1', 8765
SITE = 'https://jtarmory.com'
CENT = Decimal('0.01')
def money(v): return Decimal(str(v)).quantize(CENT, rounding=ROUND_HALF_UP)
def cents(v): return int((money(v)*100).to_integral_value())
def connect():
    c=sqlite3.connect(DB, timeout=10)
    c.row_factory=sqlite3.Row
    return c

def backup_database(force=False):
    """Use SQLite online backup so WAL/uncommitted state cannot corrupt copies."""
    if not DB.exists():return None
    folder=ROOT/'backups';folder.mkdir(exist_ok=True)
    target=folder/('jtarmory_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.sqlite3' if force else 'jtarmory_'+date.today().strftime('%Y%m%d')+'.sqlite3')
    if target.exists() and not force:return str(target)
    with sqlite3.connect(DB,timeout=30) as original,sqlite3.connect(target) as copy:
        original.backup(copy)
        if copy.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise RuntimeError('Backup failed integrity check')
    # Keep most recent 30 daily and manual backups; never delete backups outside this folder.
    copies=sorted(folder.glob('jtarmory_*.sqlite3'),key=lambda x:x.stat().st_mtime,reverse=True)
    for old in copies[30:]:old.unlink()
    return str(target)

def audit(c,action,reference,before=None,after=None):
    c.execute('INSERT INTO audit_log(at,action,reference,before_json,after_json) VALUES(?,?,?,?,?)',(
       datetime.now().isoformat(timespec='seconds'),action,str(reference),json.dumps(before,default=str),json.dumps(after,default=str)))

def init():
    with connect() as c:
        c.executescript('''CREATE TABLE IF NOT EXISTS products (upc TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL, source TEXT NOT NULL DEFAULT 'manual', updated TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sales (id INTEGER PRIMARY KEY AUTOINCREMENT, timestamp TEXT NOT NULL, subtotal_cents INTEGER NOT NULL, tax_cents INTEGER NOT NULL, fee_cents INTEGER NOT NULL, total_cents INTEGER NOT NULL, method TEXT NOT NULL, items_json TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS settings (k TEXT PRIMARY KEY, v TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS product_pages (upc TEXT PRIMARY KEY, url TEXT NOT NULL);''')
        cols={r['name'] for r in c.execute('PRAGMA table_info(sales)')}
        for name,typ,default in [('discount_cents','INTEGER','0'),('discount_type','TEXT',"'none'"),('discount_rate','TEXT',"'0'"),('layaway_id','INTEGER','NULL'),('customer','TEXT',"''")]:
            if name not in cols:c.execute(f'ALTER TABLE sales ADD COLUMN {name} {typ} DEFAULT {default}')
        if 'cost_cents' not in cols:c.execute('ALTER TABLE sales ADD COLUMN cost_cents INTEGER DEFAULT NULL')
        if 'item_costs_json' not in cols:c.execute('ALTER TABLE sales ADD COLUMN item_costs_json TEXT DEFAULT NULL')
        c.execute("INSERT OR IGNORE INTO settings VALUES ('search_url','https://jtarmory.com/search?query={upc}')")
        c.execute("INSERT OR IGNORE INTO settings VALUES ('suggestions_url','https://jtarmory.com/api/search-suggestions?searchText={upc}&inStockOnly=false')")
        c.execute("INSERT OR IGNORE INTO settings VALUES ('leo_discount','0')")
        c.execute("INSERT OR IGNORE INTO settings VALUES ('military_discount','0')")
        c.execute("INSERT OR IGNORE INTO settings VALUES ('service_discount','0')")
        for k,v in BUSINESS_DEFAULTS.items():c.execute('INSERT OR IGNORE INTO settings(k,v) VALUES (?,?)',(k,v))
        c.executescript('''CREATE TABLE IF NOT EXISTS layaways (
            id INTEGER PRIMARY KEY AUTOINCREMENT, created TEXT NOT NULL, customer TEXT NOT NULL,
            contact TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'open',
            items_json TEXT NOT NULL, discount_type TEXT NOT NULL DEFAULT 'none', discount_rate TEXT NOT NULL DEFAULT '0',
            subtotal_cents INTEGER NOT NULL, discount_cents INTEGER NOT NULL,
            tax_cents INTEGER NOT NULL, total_cents INTEGER NOT NULL, closed TEXT);
        CREATE TABLE IF NOT EXISTS layaway_payments (
            id INTEGER PRIMARY KEY AUTOINCREMENT, layaway_id INTEGER NOT NULL, paid TEXT NOT NULL,
            amount_cents INTEGER NOT NULL CHECK(amount_cents>0), method TEXT NOT NULL, note TEXT NOT NULL DEFAULT '',
            FOREIGN KEY(layaway_id) REFERENCES layaways(id));
        CREATE TABLE IF NOT EXISTS layaway_voids (
            layaway_id INTEGER PRIMARY KEY, voided TEXT NOT NULL, reason TEXT NOT NULL,
            refund_cents INTEGER NOT NULL, refund_method TEXT NOT NULL, FOREIGN KEY(layaway_id) REFERENCES layaways(id));
        CREATE TABLE IF NOT EXISTS sale_returns (
            id INTEGER PRIMARY KEY AUTOINCREMENT, sale_id INTEGER NOT NULL, timestamp TEXT NOT NULL,
            items_json TEXT NOT NULL, merchandise_cents INTEGER NOT NULL, tax_cents INTEGER NOT NULL,
            fee_cents INTEGER NOT NULL, refund_cents INTEGER NOT NULL, method TEXT NOT NULL,
            reason TEXT NOT NULL, FOREIGN KEY(sale_id) REFERENCES sales(id));''')
        pcols={r['name'] for r in c.execute('PRAGMA table_info(layaway_payments)')}
        if 'fee_cents' not in pcols:c.execute('ALTER TABLE layaway_payments ADD COLUMN fee_cents INTEGER NOT NULL DEFAULT 0')
        c.execute('''CREATE TABLE IF NOT EXISTS audit_log(id INTEGER PRIMARY KEY AUTOINCREMENT,at TEXT NOT NULL,action TEXT NOT NULL,reference TEXT NOT NULL,before_json TEXT,after_json TEXT)''')
        c.executescript("CREATE TABLE IF NOT EXISTS gift_cards (code TEXT PRIMARY KEY, balance_cents INTEGER NOT NULL DEFAULT 0 CHECK(balance_cents>=0), created TEXT NOT NULL, updated TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'active'); CREATE TABLE IF NOT EXISTS gift_card_ledger (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL, timestamp TEXT NOT NULL, delta_cents INTEGER NOT NULL, event TEXT NOT NULL, reference TEXT NOT NULL DEFAULT '', method TEXT NOT NULL DEFAULT '', note TEXT NOT NULL DEFAULT '', FOREIGN KEY(code) REFERENCES gift_cards(code));")
        gcols={r['name'] for r in c.execute('PRAGMA table_info(gift_card_ledger)')}
        if 'fee_cents' not in gcols:c.execute('ALTER TABLE gift_card_ledger ADD COLUMN fee_cents INTEGER NOT NULL DEFAULT 0')
        if 'collected_cents' not in gcols:c.execute('ALTER TABLE gift_card_ledger ADD COLUMN collected_cents INTEGER NOT NULL DEFAULT 0')
        if 'gift_code' not in cols:c.execute('ALTER TABLE sales ADD COLUMN gift_code TEXT DEFAULT NULL')
        if 'gift_cents' not in cols:c.execute('ALTER TABLE sales ADD COLUMN gift_cents INTEGER NOT NULL DEFAULT 0')
        c.execute('''CREATE TABLE IF NOT EXISTS sale_voids(sale_id INTEGER PRIMARY KEY,voided_at TEXT NOT NULL,reason TEXT NOT NULL, original_sale_json TEXT NOT NULL,FOREIGN KEY(sale_id) REFERENCES sales(id))''')

def product(upc):
    with connect() as c:
        r=c.execute('SELECT * FROM products WHERE upc=?',(upc,)).fetchone()
    return dict(r) if r else None

def json_products(data):
    if isinstance(data,list):
        for x in data: yield from json_products(x)
    elif isinstance(data,dict):
        if data.get('@type') == 'Product' or (isinstance(data.get('@type'),list) and 'Product' in data['@type']): yield data
        for k,v in data.items():
            if k in ('@graph','mainEntity','itemListElement','item','products'): yield from json_products(v)

# Product URL explicitly supplied by store owner; this is NOT a stored price.
KNOWN_PAGES = {
    '850059086315': SITE + '/shooting-sports/nfa-suppressors/suppressors/cat-ben-a1/detail/0bc94905-16df-4246-a920-4a0188d89e73/40f8f43f-9f1c-4885-bf89-64144f5aee33',
}

def get_html(url):
    req=Request(url,headers={
      'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
      'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      'Accept-Language':'en-US,en;q=0.9'
    })
    with urlopen(req,timeout=9) as response:
        if urlparse(response.url).hostname not in ('jtarmory.com','www.jtarmory.com'):
            raise ValueError('Search redirected outside JTArmory.com')
        return response.read(2500000).decode('utf-8','replace')

def product_from_page(html, upc, url, trusted_link=False):
    # Only use product-scoped fields (not random dollar values from elsewhere on the page).
    blocks=re.findall(r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',html,re.I|re.S)
    for block in blocks:
        try: data=json.loads(unescape(block))
        except (TypeError, ValueError): continue
        for p in json_products(data):
            identifiers=[str(p.get(k,'')) for k in ('gtin','gtin12','gtin13','gtin14','sku','productID','mpn','upc')]
            if not trusted_link and upc not in identifiers: continue
            offers=p.get('offers') or {}
            if isinstance(offers,list): offers=next((o for o in offers if isinstance(o,dict) and (o.get('price') is not None or o.get('lowPrice') is not None)),{})
            if isinstance(offers,dict):
                price=offers.get('price') or offers.get('lowPrice')
                if price is not None and p.get('name'):
                    try: return {'upc':upc,'name':str(p['name']),'price_cents':cents(price),'source':'website','url':url}
                    except (InvalidOperation,ValueError): pass
    if trusted_link:
        # Product-specific OpenGraph metadata is common on storefronts.
        def meta(key):
            for tag in re.findall(r'<meta\b[^>]*>',html,re.I):
                if re.search(r'(?:property|name)=["\']'+re.escape(key)+r'["\']',tag,re.I):
                    m=re.search(r'content=["\']([^"\']+)',tag,re.I)
                    if m:return unescape(m.group(1)).strip()
            return None
        title=meta('og:title')
        price=meta('product:price:amount') or meta('og:price:amount')
        if title and price:
            try: return {'upc':upc,'name':title,'price_cents':cents(price),'source':'website','url':url}
            except (InvalidOperation,ValueError): pass
    return None

def slug(value):
    """Match storefront's lower-case category and model URL structure."""
    value=str(value or '').lower().strip().replace('&','and')
    value=re.sub(r'[^a-z0-9]+','-',value)
    return value.strip('-')

def suggestion_candidates(upc):
    """Use Gearfire's browser-observed search-suggestions request.

    Exact prefix may vary by deployment; configurable in Settings.
    """
    with connect() as c:
        row=c.execute("SELECT v FROM settings WHERE k='suggestions_url'").fetchone()
    configured=row['v'] if row else ''
    patterns=[configured,
        SITE+'/api/search-suggestions?searchText={upc}&inStockOnly=false',
        SITE+'/search-suggestions?searchText={upc}&inStockOnly=false',
        SITE+'/api/products/search-suggestions?searchText={upc}&inStockOnly=false',
        SITE+'/api/product/search-suggestions?searchText={upc}&inStockOnly=false']
    for pat in dict.fromkeys(patterns):
        if '{upc}' not in pat:continue
        url=pat.replace('{upc}',quote(upc,safe=''))
        parsed=urlparse(url)
        if parsed.scheme=='https' and parsed.hostname in ('jtarmory.com','www.jtarmory.com'):
            yield url

def fetch_suggestions(url):
    req=Request(url,headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0 Safari/537.36',
        'Accept':'application/json, text/plain, */*','Referer':SITE+'/home',
        'Accept-Language':'en-US,en;q=0.9'})
    with urlopen(req,timeout=7) as response:
        if urlparse(response.url).hostname not in ('jtarmory.com','www.jtarmory.com'):
            raise ValueError('Redirected to another site')
        payload=response.read(500000).decode('utf-8','replace')
        return json.loads(payload)

def find_suggestions(data):
    if isinstance(data,list):
        for item in data:yield from find_suggestions(item)
    elif isinstance(data,dict):
        if data.get('productId') and (data.get('subProductId') or data.get('subproductId')):
            yield data
        else:
            for value in data.values():
                if isinstance(value,(list,dict)):yield from find_suggestions(value)

def suggestion_url(entry):
    info=next((x for x in (entry.get('departmentInfos') or []) if x.get('isPrimary')),None)
    if not info:info=next(iter(entry.get('departmentInfos') or []),{})
    dept=slug(info.get('departmentName'))
    category=slug(info.get('categoryName'))
    subcategory=slug(info.get('subCategoryName'))
    name=slug(entry.get('modelName'))
    productid=str(entry['productId'])
    subid=str(entry.get('subProductId') or entry.get('subproductId'))
    # Same /department/category/subcategory/model/detail/productId/subProductId
    # structure as the live CAT/BEN/A1 page supplied by the shop.
    if not (dept and category and subcategory and name):return None
    if not all(re.fullmatch(r'[a-fA-F0-9-]{36}',x) for x in (productid,subid)):return None
    return SITE+'/'+ '/'.join([dept,category,subcategory,name,'detail',productid,subid])

def webpage_search(upc):
    """Lookup Gearfire suggestions, then price only from UPC-verified detail HTML."""
    errors=[];candidates=[]
    with connect() as c:
        row=c.execute('SELECT url FROM product_pages WHERE upc=?',(upc,)).fetchone()
    saved_url=row['url'] if row else None
    if saved_url:candidates.append(saved_url)
    if upc in KNOWN_PAGES:candidates.append(KNOWN_PAGES[upc])
    found_response=False
    for url in suggestion_candidates(upc):
        try:
            data=fetch_suggestions(url)
            found_response=True
            entries=list(find_suggestions(data))
            if not entries:errors.append('No suggestions returned by '+urlparse(url).path)
            for entry in entries[:15]:
                candidate=suggestion_url(entry)
                if candidate:candidates.append(candidate)
            if entries:break
        except Exception as exc:
            errors.append('Suggestions '+urlparse(url).path+': '+str(exc)[:140])
    for url in dict.fromkeys(candidates):
        if urlparse(url).hostname not in ('jtarmory.com','www.jtarmory.com'):continue
        try:
            result=product_from_page(get_html(url),upc,url,trusted_link=False)
            if result:return result,errors
            errors.append('Product page UPC/price did not match: '+urlparse(url).path)
        except Exception as exc:errors.append('Detail request: '+str(exc)[:140])
    if not found_response:errors.append('Gearfire suggestions endpoint could not be reached; check full Request URL in Chrome Network > Headers.')
    return None,errors

def saved_page_url(upc):
    with connect() as c:
        row=c.execute('SELECT url FROM product_pages WHERE upc=?',(upc,)).fetchone()
    return row['url'] if row else None

def discount_rate(discount_type):
    if discount_type not in ('none','leo','military','service'):raise ValueError('Invalid discount type')
    if discount_type=='none':return Decimal('0')
    with connect() as c:
        row=c.execute('SELECT v FROM settings WHERE k=?',(discount_type+'_discount',)).fetchone()
    rate=Decimal(row['v'] if row else '0')
    if rate<0 or rate>100:raise ValueError('Invalid configured discount rate')
    return rate

def totals(items, credit=False, discount_type='none'):
    subtotal=sum(int(x['price_cents'])*int(x['qty']) for x in items)
    taxable=sum(int(x['price_cents'])*int(x['qty']) for x in items if x.get('taxable',True))
    rate=discount_rate(discount_type)
    discount=int((Decimal(subtotal)*rate/100).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
    taxable_discount=int((Decimal(taxable)*rate/100).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
    tax=int((Decimal(taxable-taxable_discount)*Decimal('.06')).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
    net=subtotal-discount
    fee=int((Decimal(net+tax)*Decimal('.03')).quantize(Decimal('1'),rounding=ROUND_HALF_UP)) if credit else 0
    return {'subtotal_cents':subtotal,'discount_cents':discount,'discount_type':discount_type,
            'discount_rate':str(rate),'tax_cents':tax,'fee_cents':fee,'total_cents':net+tax+fee}

BUSINESS_DEFAULTS={
    'business_name':'JTArmory LLC',
    'business_address1':'348 Montgomery Rd',
    'business_address2':'Rising Sun, MD 21911',
    'business_phone':'(443) 212-8196',
    'business_website':'jtarmory.com',
    'business_email':'',
    'business_receipt_note':'Thank you for shopping with us!',
    'business_label_name':'JTArmory',
    'business_label_phone':'1-833-263-4473',
}
BUSINESS_KEYS=tuple(BUSINESS_DEFAULTS)
def business_profile():
    with connect() as c:
        records={r['k']:r['v'] for r in c.execute('SELECT k,v FROM settings WHERE k LIKE ?',('business_%',))}
    return {key:records.get(key,default) for key,default in BUSINESS_DEFAULTS.items()}

GIFT_RE=re.compile(r'^JTARMORY-GIFTCARD-([1-9][0-9]{0,8})$',re.I)
def gift_code(raw):
    code=str(raw or '').strip().upper()
    if not GIFT_RE.fullmatch(code):raise ValueError('Gift barcode must look like JTARMORY-GIFTCARD-4')
    return code

def gift_load(code,amount,method,note,charge_fee=False,collected_cents=None):
    if not isinstance(amount,int) or amount<=0 or amount>10000000:raise ValueError('Amount must be between $0.01 and $100,000')
    if method not in ('cash','credit','other','adjustment'):raise ValueError('Select a valid payment method')
    if len(note)>300:raise ValueError('Note too long')
    if method!='credit' and charge_fee:raise ValueError('Card surcharge only applies to credit')
    fee=int((Decimal(amount)*Decimal('.03')).quantize(Decimal('1'),rounding=ROUND_HALF_UP)) if method=='credit' and charge_fee else 0
    if collected_cents!=amount+fee:raise ValueError('Confirm the exact amount collected before loading the card')
    now=datetime.now().isoformat(timespec='seconds')
    with connect() as c:
        c.execute('BEGIN IMMEDIATE')
        c.execute("INSERT OR IGNORE INTO gift_cards(code,balance_cents,created,updated) VALUES(?,?,?,?)",(code,0,now,now))
        row=c.execute('SELECT balance_cents,status FROM gift_cards WHERE code=?',(code,)).fetchone()
        if row['status']!='active':raise ValueError('Gift card is inactive')
        before=row['balance_cents'];new=before+amount
        if new>10000000:raise ValueError('Gift card maximum balance is $100,000')
        c.execute('UPDATE gift_cards SET balance_cents=?,updated=? WHERE code=?',(new,now,code))
        c.execute('INSERT INTO gift_card_ledger(code,timestamp,delta_cents,event,method,note,fee_cents,collected_cents) VALUES(?,?,?,?,?,?,?,?)',(code,now,amount,'load' if method!='adjustment' else 'adjustment',method,note,fee,collected_cents))
        audit(c,'gift_card_load',code,{'balance_cents':before},{'balance_cents':new,'added_cents':amount,'method':method,'fee_cents':fee,'collected_cents':collected_cents})
    return new

def clean_items(items):
    if not isinstance(items,list) or not items or len(items)>200:raise ValueError('Add items first')
    clean=[]
    for x in items:
        name=str(x['name']).strip();qty=int(x['qty']);pc=int(x['price_cents']);upc=str(x.get('upc',''))
        if not name or len(name)>250 or qty<1 or qty>10000 or pc<0 or pc>100000000:raise ValueError('Invalid line item')
        clean.append({'upc':upc[:80],'name':name,'qty':qty,'price_cents':pc,'taxable':bool(x.get('taxable',True))})
    return clean

def layaway_detail(layaway_id):
    with connect() as c:
        r=c.execute('SELECT * FROM layaways WHERE id=?',(layaway_id,)).fetchone()
        if not r:return None
        result=dict(r)
        result['payments']=[dict(x) for x in c.execute('SELECT * FROM layaway_payments WHERE layaway_id=? ORDER BY id',(layaway_id,))]
    result['paid_cents']=sum(x['amount_cents'] for x in result['payments'])
    result['card_fees_cents']=sum(x.get('fee_cents',0) for x in result['payments'])
    result['charged_cents']=result['paid_cents']+result['card_fees_cents']
    with connect() as c:
        v=c.execute('SELECT * FROM layaway_voids WHERE layaway_id=?',(layaway_id,)).fetchone()
    result['void_info']=dict(v) if v else None
    result['balance_cents']=0 if result['status']=='voided' else result['total_cents']-result['paid_cents']
    return result

def sales_period(qs):
    """Server-side, inclusive local-date filters, with bounded named periods."""
    period=qs.get('period',['all'])[0]
    today=date.today()
    if period=='all':return None,None
    if period=='today':return today.isoformat(),today.isoformat()
    if period=='month':return date(today.year,today.month,1).isoformat(),today.isoformat()
    if period=='week':
        from datetime import timedelta
        return (today-timedelta(days=today.weekday())).isoformat(),today.isoformat()
    if period in ('quarter','annual'):
        target_year=int(qs.get('year',[str(today.year)])[0])
        if target_year<2000 or target_year>2100:raise ValueError('Invalid report year')
        if period=='quarter':
            quarter=int(qs.get('quarter',[str((today.month-1)//3+1)])[0])
            if quarter not in (1,2,3,4):raise ValueError('Invalid quarter')
            start_month=(quarter-1)*3+1
            end_month=start_month+2
            from calendar import monthrange
            return date(target_year,start_month,1).isoformat(),date(target_year,end_month,monthrange(target_year,end_month)[1]).isoformat()
        return date(target_year,1,1).isoformat(),date(target_year,12,31).isoformat()
    if period=='year':return date(today.year,1,1).isoformat(),today.isoformat()
    if period=='custom':
        start=qs.get('start',[''])[0];end=qs.get('end',[''])[0]
        a=date.fromisoformat(start);b=date.fromisoformat(end)
        if a>b:raise ValueError('Start date must be on or before end date')
        return a.isoformat(),b.isoformat()
    raise ValueError('Invalid report period')

def get_sales(qs):
    start,end=sales_period(qs)
    where='';args=[]
    if start:
        where=' AND substr(timestamp,1,10) BETWEEN ? AND ?';args=[start,end]
    with connect() as c:
        rows=[dict(r) for r in c.execute('SELECT * FROM sales WHERE id NOT IN (SELECT sale_id FROM sale_voids)'+where+' ORDER BY timestamp DESC,id DESC',args)]
        returns=[dict(r) for r in c.execute('SELECT * FROM sale_returns WHERE sale_id NOT IN (SELECT sale_id FROM sale_voids)'+where+' ORDER BY timestamp DESC,id DESC',args)]
        for r in rows:
            r['returns']=[dict(x) for x in c.execute('SELECT * FROM sale_returns WHERE sale_id=? ORDER BY id',(r['id'],))]
    return rows,returns

def output(obj,code=200): return code,json.dumps(obj,ensure_ascii=False).encode('utf-8'),'application/json; charset=utf-8'

def make_label_pdf(item, quantity):
    """Portrait PDF matching 0.98 x 2.97 label stock, artwork sideways to fill the long side.
    Keep browser printing in Portrait with Actual size (not Fit to printable area).
    """
    from reportlab.pdfgen import canvas
    from reportlab.graphics.barcode import code128, eanbc
    from reportlab.graphics import renderPDF
    from reportlab.graphics.shapes import Drawing
    from reportlab.pdfbase.pdfmetrics import stringWidth

    PAGE_W, PAGE_H = .98 * 72, 2.97 * 72
    out_data = io.BytesIO()
    out = canvas.Canvas(out_data, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    out.setTitle('Product label - portrait 0.98 x 2.97 inch, longways art')
    profile = business_profile()

    def fit(t, font, width, size=9, min_size=5.5):
        while size > min_size and stringWidth(t, font, size) > width:
            size -= .25
        if stringWidth(t, font, size) > width:
            while t and stringWidth(t + '...', font, size) > width:
                t = t[:-1]
            t += '...'
        return t, size

    def valid_upca(v):
        if not (len(v) == 12 and v.isascii() and v.isdecimal()):
            return False
        d = [int(c) for c in v]
        return (10 - (3 * sum(d[0:11:2]) + sum(d[1:11:2])) % 10) % 10 == d[-1]

    for _ in range(quantity):
        code = str(item['upc']).strip()
        title = str(item['name']).strip()
        price = f"${item['price_cents']/100:,.2f}"

        # Physical paper is portrait, but art is rotated -90 degrees. Drawing is
        # inset 0.05 in on each edge, so usable area is 2.87 x 0.88 in.
        out.saveState()
        out.translate(0, PAGE_H)
        out.rotate(-90)
        W, H = PAGE_H, PAGE_W
        m = 9.6

        out.setFillColorRGB(0, 0, 0)
        brand, bs = fit(profile['business_label_name'], 'Helvetica-Bold', 86, 9.5, 6.5)
        out.setFont('Helvetica-Bold', bs)
        out.drawString(m, H - 14, brand)

        pr, ps = fit(price, 'Helvetica-Bold', 70, 10.5, 7.5)
        out.setFont('Helvetica-Bold', ps)
        out.drawRightString(W - m, H - 14, pr)

        product, ts = fit(title, 'Helvetica', W - 2*m, 8, 6)
        out.setFont('Helvetica', ts)
        out.drawString(m, H - 27, product)

        is_upc = valid_upca(code)
        barcode = None
        if is_upc:
            # Standard UPC-A, no horizontal squeezing.
            candidate = eanbc.UPCA(value=code, barWidth=.92, barHeight=19, humanReadable=False)
            x0, y0, x1, y1 = candidate.getBounds()
            bw = x1 - x0
            if bw <= (W - 2*m):
                barcode = ('upc', candidate, bw, x0, y0, x1, y1)
        else:
            for mod in (.72, .66, .60, .54, .48, .42):
                candidate = code128.Code128(code, barWidth=mod, barHeight=19, humanReadable=False)
                if candidate.width <= (W - 2*m):
                    barcode = ('code128', candidate)
                    break

        bar_y = 18
        if barcode:
            if barcode[0] == 'upc':
                _, candidate, bw, x0, y0, x1, y1 = barcode
                draw_x = (W - bw) / 2 - x0
                draw_y = bar_y - y0
                drawing = Drawing(x1 - x0, y1 - y0)
                drawing.add(candidate)
                renderPDF.draw(drawing, out, draw_x, draw_y)
            else:
                _, candidate = barcode
                out.saveState()
                out.translate((W - candidate.width) / 2, bar_y)
                candidate.drawOn(out, 0, 0)
                out.restoreState()
        else:
            msg, ms = fit('SKU too long for barcode', 'Helvetica-Bold', W - 2*m, 7, 6)
            out.setFont('Helvetica-Bold', ms)
            out.drawCentredString(W/2, 25, msg)

        kind = 'UPC' if is_upc else 'SKU'
        out.setFont('Helvetica', 6)
        out.drawCentredString(W/2, 7, f'{kind}: {code}')

        out.restoreState()
        out.showPage()

    out.save()
    return out_data.getvalue()

def handler():
 class H(BaseHTTPRequestHandler):
    def log_message(self,*args): pass
    def sendout(self,b,code=200,typ='application/json; charset=utf-8',name=None):
        self.send_response(code);self.send_header('Content-Type',typ);self.send_header('Content-Length',str(len(b)))
        if name:self.send_header('Content-Disposition','attachment; filename="'+name+'"')
        self.end_headers();self.wfile.write(b)
    def do_GET(self):
        p=urlparse(self.path);qs=parse_qs(p.query)
        try:
            if p.path=='/':
                b=(ROOT/'index.html').read_bytes(); return self.sendout(b,200,'text/html; charset=utf-8')
            if p.path=='/api/gift-card':
                code=gift_code(qs.get('code',[''])[0]);
                with connect() as c:
                    row=c.execute('SELECT * FROM gift_cards WHERE code=?',(code,)).fetchone()
                    entries=[dict(x) for x in c.execute('SELECT timestamp,delta_cents,event,reference,method,note FROM gift_card_ledger WHERE code=? ORDER BY id DESC LIMIT 50',(code,))]
                return self.sendout(output({'card':dict(row) if row else None,'code':code,'history':entries})[1])
            if p.path=='/api/gift-cards':
                with connect() as c:
                    rows=[dict(x) for x in c.execute('SELECT code,balance_cents,status,updated FROM gift_cards ORDER BY updated DESC LIMIT 250')]
                return self.sendout(output({'cards':rows})[1])
            if p.path=='/api/lookup':
                upc=qs.get('upc',[''])[0].strip()
                if not upc or len(upc)>80:return self.sendout(output({'error':'Invalid UPC'},400)[1],400)
                r=product(upc)
                if r and r['source']!='website':return self.sendout(output({'product':r,'verified':False,'message':'Locally saved price; check current website pricing.'})[1])
                r, diagnostics=webpage_search(upc)
                if r:
                    with connect() as c:c.execute('INSERT OR REPLACE INTO products(upc,name,price_cents,source,updated) VALUES(?,?,?,?,?)',(upc,r['name'],r['price_cents'],'website',datetime.now().isoformat(timespec='seconds')))
                    return self.sendout(output({'product':r,'verified':True})[1])
                return self.sendout(output({'product':None,'message':'Unable to verify UPC '+upc+' and its price from the public website. This is a website access/data issue, not a scanner issue. Enter it manually or import a Gearfire product CSV.', 'diagnostics':diagnostics, 'website_search': SITE+'/search?query='+quote(upc), 'known_product_url': (saved_page_url(upc) or KNOWN_PAGES.get(upc)), 'saved_price':r if r else None})[1])
            if p.path=='/api/page':
                upc=qs.get('upc',[''])[0].strip()
                with connect() as c:r=c.execute('SELECT url FROM product_pages WHERE upc=?',(upc,)).fetchone()
                return self.sendout(output({'url':r['url'] if r else ''})[1])
            if p.path=='/api/product-label.pdf':
                upc=qs.get('upc',[''])[0].strip()
                if not upc or len(upc)>100:return self.sendout(output({'error':'Invalid UPC or SKU'},400)[1],400)
                try:qty=int(qs.get('qty',['1'])[0])
                except ValueError:return self.sendout(output({'error':'Invalid label quantity'},400)[1],400)
                if qty<1 or qty>100:return self.sendout(output({'error':'Label count must be 1-100'},400)[1],400)
                item=product(upc)
                if not item:return self.sendout(output({'error':'Product not in local catalog'},404)[1],404)
                try:b=make_label_pdf(item,qty)
                except ImportError:return self.sendout(output({'error':'PDF labels require reportlab. Install it with: py -3 -m pip install reportlab'},500)[1],500)
                safe_name=re.sub(r'[^A-Za-z0-9_-]+','_',upc)[:50]
                # Open PDFs in the browser's built-in print preview instead of forcing a download.
                self.send_response(200)
                self.send_header('Content-Type','application/pdf')
                self.send_header('Content-Length',str(len(b)))
                self.send_header('Content-Disposition',f'inline; filename="JTArmory_Label_{safe_name}.pdf"')
                self.send_header('Cache-Control','no-store')
                self.end_headers()
                self.wfile.write(b)
                return
            if p.path=='/api/products':
                q=qs.get('q',[''])[0]
                with connect() as c: rows=[dict(r) for r in c.execute('SELECT * FROM products WHERE upc LIKE ? OR name LIKE ? ORDER BY updated DESC LIMIT 100',('%'+q+'%','%'+q+'%'))]
                return self.sendout(output({'products':rows})[1])
            if p.path=='/api/layaways':
                with connect() as c:
                    rows=[dict(x) for x in c.execute('''SELECT l.*,(SELECT COALESCE(SUM(amount_cents),0) FROM layaway_payments p WHERE p.layaway_id=l.id) AS paid_cents FROM layaways l ORDER BY l.id DESC LIMIT 250''')]
                for x in rows:x['balance_cents']=0 if x['status']=='voided' else x['total_cents']-x['paid_cents']
                return self.sendout(output({'layaways':rows})[1])
            if p.path.startswith('/api/layaway/'):
                lid=int(p.path.split('/')[-1]);return self.sendout(output({'layaway':layaway_detail(lid)})[1])
            if p.path=='/api/sales':
                start,end=sales_period(qs)
                rows,returns=get_sales(qs)
                # Financial summary by transaction date; completed layaway card fees are
                # payments, not additional merchandise revenue.
                merchandise=sum(x['subtotal_cents']-x['discount_cents'] for x in rows)-sum(x['merchandise_cents'] for x in returns)
                taxes=sum(x['tax_cents'] for x in rows)-sum(x['tax_cents'] for x in returns)
                fees=sum(x['fee_cents'] for x in rows)-sum(x['fee_cents'] for x in returns)
                with connect() as ac:
                    if start:
                        lpfees=ac.execute('SELECT COALESCE(SUM(fee_cents),0) FROM layaway_payments WHERE substr(paid,1,10) BETWEEN ? AND ?',(start,end)).fetchone()[0]
                    else:
                        lpfees=ac.execute('SELECT COALESCE(SUM(fee_cents),0) FROM layaway_payments').fetchone()[0]
                # Cost of goods, including exact per-unit reversal when available.
                # Unknown costs remain unknown; never display guessed profitability.
                net_cost=0; cost_known=True
                for sale in rows:
                    unit_costs=None
                    try: unit_costs=json.loads(sale.get('item_costs_json') or 'null')
                    except (TypeError,ValueError):pass
                    if sale['cost_cents'] is None:
                        cost_known=False;continue
                    net_cost+=sale['cost_cents']
                    for returned in sale['returns']:
                        parts=json.loads(returned['items_json'])
                        if isinstance(unit_costs,list) and all(0<=int(part['index'])<len(unit_costs) and unit_costs[int(part['index'])] is not None for part in parts):
                            net_cost-=sum(unit_costs[int(part['index'])]*int(part['qty']) for part in parts)
                        else:
                            # Legacy cost-only transaction: estimate cannot be used as exact profit.
                            cost_known=False
                # Returns originating outside the selected period cannot reliably
                # provide current-period cost without a separate item-cost lookup.
                selected_ids={x['id'] for x in rows}
                if any(x['sale_id'] not in selected_ids for x in returns):cost_known=False
                summary={'sales_cents':sum(x['total_cents'] for x in rows),
                         'returns_cents':sum(x['refund_cents'] for x in returns),
                         'net_cents':merchandise, 'merchandise_cents':merchandise,'tax_cents':taxes,
                         'fee_cents':fees+lpfees,'card_fees_layaway_cents':lpfees,'cost_cents':net_cost if cost_known else None,'gross_profit_cents':merchandise-net_cost if cost_known else None,
                         'receipts_cents':sum(x['total_cents'] for x in rows)-sum(x['refund_cents'] for x in returns),
                         'sale_count':len(rows),'return_count':len(returns)}
                return self.sendout(output({'sales':rows,'returns':returns,'summary':summary})[1])
            if p.path=='/api/sales.xlsx':
                return self.sales_excel(qs)
            if p.path=='/api/sales.csv':
                s=io.StringIO();w=csv.writer(s)
                w.writerow(['Type','Reference #','Date','Customer/Reason','Method','Merchandise','Discount','Tax','Card Fee','Total'])
                rows,returns=get_sales(qs)
                for r in rows:
                    w.writerow(['SALE',r['id'],r['timestamp'],r.get('customer',''),r['method'],
                      f"{r['subtotal_cents']/100:.2f}",f"{-r['discount_cents']/100:.2f}",
                      f"{r['tax_cents']/100:.2f}",f"{r['fee_cents']/100:.2f}",f"{r['total_cents']/100:.2f}"])
                for r in returns:
                    w.writerow(['RETURN',r['id'],r['timestamp'],'Sale #'+str(r['sale_id'])+': '+r['reason'],r['method'],
                        f"{-r['merchandise_cents']/100:.2f}",'0.00',f"{-r['tax_cents']/100:.2f}",
                        f"{-r['fee_cents']/100:.2f}",f"{-r['refund_cents']/100:.2f}"])
                return self.sendout(s.getvalue().encode('utf-8-sig'),200,'text/csv; charset=utf-8','jtarmory_sales_and_returns.csv')
            if p.path.startswith('/api/receipt/'):
                i=int(p.path.split('/')[-1]);
                with connect() as c:r=c.execute('SELECT * FROM sales WHERE id=? AND id NOT IN (SELECT sale_id FROM sale_voids)',(i,)).fetchone()
                sale=dict(r) if r else None
                if sale and sale.get('layaway_id'):
                    # Historical layaway card fees are separate payment charges, not sale revenue.
                    sale['layaway_detail']=layaway_detail(sale['layaway_id'])
                return self.sendout(output({'sale':sale})[1])
            if p.path=='/api/audit':
                with connect() as c:rows=[dict(x) for x in c.execute('SELECT * FROM audit_log ORDER BY id DESC LIMIT 200')]
                return self.sendout(output({'events':rows})[1])
            if p.path=='/api/update/check':
                from updater import available
                return self.sendout(output(available())[1])
            if p.path=='/api/update/config':
                import updater
                return self.sendout(output({'repository':updater.repo(),'version':updater.version()})[1])
            if p.path=='/api/settings':
                with connect() as c:r=c.execute("SELECT v FROM settings WHERE k='search_url'").fetchone()
                s=c.execute("SELECT v FROM settings WHERE k='suggestions_url'").fetchone()
                rates={x['k']:x['v'] for x in c.execute("SELECT k,v FROM settings WHERE k IN ('leo_discount','military_discount','service_discount')")}
                return self.sendout(output({'search_url':r['v'],'suggestions_url':s['v'] if s else '',**rates,'business':business_profile()})[1])
            return self.sendout(output({'error':'Not found'},404)[1],404)
        except Exception as e:return self.sendout(output({'error':str(e)},500)[1],500)
    def sales_excel(self, qs):
        # Saved sale costs populate Excel automatically; blanks remain editable.
        try:
            from openpyxl import Workbook
            from openpyxl.styles import Font, PatternFill, Alignment
            from openpyxl.utils import get_column_letter
            from openpyxl.worksheet.datavalidation import DataValidation
        except ImportError:
            return self.sendout(output({'error':'Excel export needs openpyxl. Run: py -3 -m pip install openpyxl'},500)[1],500)
        period=qs.get('period',['all'])[0]
        records,refunds=get_sales(qs)
        records.reverse()
        wb=Workbook(); ws=wb.active;ws.title='Sales & Profit'
        ws.append(['Date','Customer','Items and Quantity','Cost','Sale','Tax','Total','Profit','CC','Total w/ CC Fee','Sale #'])
        widths=[14,25,75,16,16,15,16,17,9,20,11]
        for col,w in enumerate(widths,1):ws.column_dimensions[get_column_letter(col)].width=w
        headfill=PatternFill('solid',fgColor='172638')
        for cell in ws[1]:cell.fill=headfill;cell.font=Font(name='Aptos',bold=True,color='FFFFFF');cell.alignment=Alignment(vertical='center')
        ws.row_dimensions[1].height=30
        ws.freeze_panes='D2';ws.sheet_view.showGridLines=False
        curr='$#,##0.00;[Red]($#,##0.00);-'
        sale_excel_rows={r['id']:(i,r) for i,r in enumerate(records,2)}
        all_sale_costs={r['id']:r['cost_cents'] for r in records}
        for i,r in enumerate(records,2):
            try: items=json.loads(r['items_json'])
            except (ValueError,TypeError):items=[]
            description=' | '.join('('+str(x.get('qty',1))+') '+str(x.get('name',''))+' ['+str(x.get('upc',''))+']' for x in items)
            try: d=datetime.fromisoformat(r['timestamp'])
            except ValueError:d=None
            # Sale = after-discount merchandise revenue, before taxes and card surcharge.
            sale=(r['subtotal_cents']-int(r.get('discount_cents') or 0))/100
            ws.append([d,r.get('customer') or '',description,(r.get('cost_cents')/100 if r.get('cost_cents') is not None else None),sale,r['tax_cents']/100,(r['total_cents']-r['fee_cents'])/100,f'=IF(D{i}="","",E{i}-D{i})', 'Yes' if r['method']=='credit' else '',(r['total_cents']/100 if r['fee_cents']>0 else None),r['id']])
            # Correct Excel formula quoting for blank cost cell
            ws[f'H{i}']=f'=IF(D{i}="","",E{i}-D{i})'.replace('\\"','"').replace('\"','"')
            ws[f'A{i}'].number_format='m/d/yy'
            for j in (4,5,6,7,8,10):ws.cell(i,j).number_format=curr
            for j in (1,2,3,5,6,7,9,10,11):ws.cell(i,j).font=Font(name='Aptos',color='00804A' if j in (1,2,3,5,6,7,8,10,11) else '303030')
            ws[f'D{i}'].fill=PatternFill('solid',fgColor='FFF3CE');ws[f'D{i}'].font=Font(name='Aptos',color='0000FF',bold=True)
            ws[f'H{i}'].font=Font(name='Aptos',color='000000',bold=True)
            ws[f'C{i}'].alignment=Alignment(wrap_text=True,vertical='center')
            ws.row_dimensions[i].height=32 if len(description)>75 else 23
            if i%2==0:
                for j in (1,2,3,5,6,7,8,9,10,11):ws.cell(i,j).fill=PatternFill('solid',fgColor='F3F7FB')
        # Returns must reverse both revenue AND corresponding cost of goods sold.
        # If original sale appears in this export, link the return's negative cost
        # to the user's editable original cost cell; profits then net correctly.
        # If original sale lies outside range, allow manually entering NEGATIVE
        # returned cost (do not guess it or report a fabricated profit).
        for rr in refunds:
            i=ws.max_row+1
            try: returned=json.loads(rr['items_json'])
            except (ValueError,TypeError):returned=[]
            if not isinstance(returned,list):returned=[]
            item_text=' | '.join('('+str(x.get('qty',1))+') '+str(x.get('name','')) for x in returned if isinstance(x,dict))
            description='RETURN: '+(item_text or 'Items not specified')
            if rr.get('reason'):description+=' — '+str(rr['reason'])
            merch=-rr['merchandise_cents']/100
            ws.append([datetime.fromisoformat(rr['timestamp']),
                'RETURN sale #'+str(rr['sale_id']),description,None,
                merch,-rr['tax_cents']/100,-(rr['refund_cents']-rr['fee_cents'])/100,
                None,'Yes' if rr.get('method')=='credit' else '',(-rr['refund_cents']/100 if rr['fee_cents']>0 else None),rr['sale_id']])
            original=next((s for s in records if s['id']==rr['sale_id']),None)
            if original is None:
                with connect() as cost_db:
                    row=cost_db.execute('SELECT items_json,item_costs_json,subtotal_cents,discount_cents,cost_cents FROM sales WHERE id=?',(rr['sale_id'],)).fetchone()
                    original=dict(row) if row else None
            exact_cost=None
            if original is not None and original.get('item_costs_json'):
                try:
                    unit_costs=json.loads(original['item_costs_json'])
                    sold_items=json.loads(original['items_json'])
                    if (isinstance(unit_costs,list) and isinstance(sold_items,list)
                        and len(unit_costs)==len(sold_items) and returned):
                        parts=[]
                        for part in returned:
                            ix=int(part['index']); n=int(part['qty'])
                            if ix<0 or ix>=len(sold_items) or n<1 or n>int(sold_items[ix]['qty']):
                                raise ValueError('Invalid return item')
                            if unit_costs[ix] is None:raise ValueError('Unit cost missing')
                            parts.append(int(unit_costs[ix])*n)
                        exact_cost=sum(parts)
                except (ValueError,KeyError,IndexError,TypeError):
                    exact_cost=None
            if exact_cost is not None:
                # A return reverses the true recorded per-item unit cost, not
                # its percentage of the original merchandise selling price.
                ws[f'D{i}']=-exact_cost/100
            elif original is not None:
                original_net=original['subtotal_cents']-int(original.get('discount_cents') or 0)
                ratio=rr['merchandise_cents']/original_net if original_net>0 else 1
                if rr['sale_id'] in sale_excel_rows:
                    # Compatibility for sales where only an aggregate cost was saved.
                    sale_row,_=sale_excel_rows[rr['sale_id']]
                    ws[f'D{i}']=f'=IF(D{sale_row}="","",-ROUND(D{sale_row}*{ratio:.12f},2))'
                elif original.get('cost_cents') is not None:
                    ws[f'D{i}']=-round(original['cost_cents']*ratio)/100
                else:
                    ws[f'D{i}']=None
            if ws[f'D{i}'].value is None:
                ws[f'D{i}'].comment=__import__('openpyxl').comments.Comment(
                    'The original item cost is not saved. Enter the NEGATIVE cost of the returned merchandise, e.g. -10.00. Save per-item costs in Sales History for exact return costs.',
                    'JTArmory POS')
            ws[f'H{i}']=f'=IF(D{i}="","",E{i}-D{i})'
            ws[f'A{i}'].number_format='m/d/yy'
            for col in ('D','E','F','G','H','J'):ws[f'{col}{i}'].number_format=curr
            for cell in ws[i]:cell.fill=PatternFill('solid',fgColor='FCE8E8')
            ws[f'D{i}'].font=Font(name='Aptos',color='0000FF' if ws[f'D{i}'].value is None else '000000',bold=True)
            if ws[f'D{i}'].value is None:ws[f'D{i}'].fill=PatternFill('solid',fgColor='FFF3CE')
            ws[f'H{i}'].font=Font(name='Aptos',color='000000',bold=True)
            ws[f'C{i}'].alignment=Alignment(wrap_text=True,vertical='center')
            ws.row_dimensions[i].height=33 if len(description)>75 else 24
        last=max(2,ws.max_row)
        ws.auto_filter.ref=f'A1:K{last}'
        total_row=ws.max_row+2
        ws.cell(total_row,3,'TOTALS')
        for col in ('D','E','F','G','H'):
            ws[f'{col}{total_row}']=f'=SUM({col}2:{col}{total_row-2})'
            ws[f'{col}{total_row}'].number_format=curr
        for cell in ws[total_row]:cell.fill=PatternFill('solid',fgColor='DCE8F2');cell.font=Font(bold=True,color='172638')
        ws[f'B{total_row+2}']='Costs saved in Sales History are included automatically. Blank yellow cells can still be entered manually.'
        ws[f'B{total_row+3}']='Total excludes the card surcharge; Total w/ CC Fee (after CC) shows charged/refunded amount with surcharge, when applicable. That column is NOT totaled.'
        ws[f'B{total_row+4}']='Returns reverse exact saved item costs when available. Legacy total-only costs use an estimated allocation; unsaved costs need manual entry.'
        ws[f'B{total_row+5}']='Excel edits are NOT saved back into the POS. To save costs permanently, use Sales History > Edit Cost.'
        for rr in range(total_row+2,total_row+6):ws[f'B{rr}'].font=Font(size=10,color='7C5B20',italic=True)
        bio=io.BytesIO();wb.save(bio)
        filename='jtarmory_sales_'+period+'.xlsx'
        return self.sendout(bio.getvalue(),200,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',filename)
    def do_DELETE(self):
        try:
            p=urlparse(self.path)
            if p.path!='/api/product':
                return self.sendout(output({'error':'Not found'},404)[1],404)
            upc=parse_qs(p.query).get('upc',[''])[0].strip()
            if not upc or len(upc)>80:
                return self.sendout(output({'error':'Invalid product code'},400)[1],400)
            with connect() as c:
                record=c.execute('SELECT source FROM products WHERE upc=?',(upc,)).fetchone()
                if record is None:
                    return self.sendout(output({'error':'Product not found'},404)[1],404)
                if record['source']!='manual':
                    return self.sendout(output({'error':'Only manually created catalog products can be deleted. Website and imported items are protected.'},403)[1],403)
                c.execute('DELETE FROM products WHERE upc=? AND source=?',(upc,'manual'))
                audit(c,'product_deleted',upc,dict(record),None)
            # Existing sales and layaways are intentionally preserved.
            return self.sendout(output({'ok':True,'deleted':upc})[1])
        except Exception as e:
            return self.sendout(output({'error':str(e)},500)[1],500)
    def do_POST(self):
        try:
            n=int(self.headers.get('Content-Length','0'))
            if n>3000000: raise ValueError('Request too large')
            data=json.loads(self.rfile.read(n))
            if self.path=='/api/gift-card/adjust':
                code=gift_code(data.get('code'))
                target=data.get('balance_cents')
                if type(target)!=int or not (0<=target<=10000000):raise ValueError('New balance must be between $0 and $100,000')
                reason=str(data.get('reason') or '').strip()
                if len(reason)<5 or len(reason)>300:raise ValueError('Enter a reason of at least 5 characters')
                if data.get('confirmed') is not True:raise ValueError('Confirm the balance adjustment')
                # Preserve the original card and ledger. Do not fabricate a payment or a sale.
                # Existing gift card redemptions remain in their original sale records.
                with connect() as c:
                    c.execute('BEGIN IMMEDIATE')
                    row=c.execute('SELECT balance_cents,status FROM gift_cards WHERE code=?',(code,)).fetchone()
                    if not row:raise ValueError('Gift card not activated. Use Load Gift Card for new cards.')
                    if row['status']!='active':raise ValueError('Gift card is inactive')
                    before=int(row['balance_cents'])
                    if before==target:raise ValueError('New balance is unchanged')
                    now=datetime.now().isoformat(timespec='seconds')
                    c.execute('UPDATE gift_cards SET balance_cents=?,updated=? WHERE code=?',(target,now,code))
                    c.execute('INSERT INTO gift_card_ledger(code,timestamp,delta_cents,event,reference,method,note) VALUES(?,?,?,?,?,?,?)',(code,now,target-before,'balance_reset' if target==0 else 'balance_adjustment','MANUAL','adjustment',reason))
                    audit(c,'gift_card_balance_adjusted',code,{'balance_cents':before},{'balance_cents':target,'reason':reason})
                return self.sendout(output({'ok':True,'code':code,'previous_balance_cents':before,'balance_cents':target})[1])
            if self.path=='/api/gift-card/load':
                code=gift_code(data.get('code'))
                amount=data.get('amount_cents')
                if type(amount)!=int:raise ValueError('Use a valid amount in cents')
                method=str(data.get('method','cash'))
                if method=='adjustment':raise ValueError('Adjustments require an approved correction workflow; use a paid load')
                collected=data.get('collected_cents')
                if type(collected)!=int or data.get('payment_confirmed') is not True:raise ValueError('Confirm the payment collected')
                new=gift_load(code,amount,method,str(data.get('note','')).strip(),bool(data.get('fee',False)),collected)
                return self.sendout(output({'ok':True,'code':code,'balance_cents':new,'amount_cents':amount,'fee_cents':collected-amount,'collected_cents':collected})[1])
            if self.path=='/api/backup':
                file=backup_database(force=True)
                return self.sendout(output({'backup':file,'ok':True})[1])
            if self.path=='/api/page':
                upc=str(data.get('upc','')).strip();url=str(data.get('url','')).strip()
                pu=urlparse(url)
                if not upc or len(upc)>80 or pu.scheme!='https' or pu.hostname not in ('jtarmory.com','www.jtarmory.com') or '/detail/' not in pu.path:raise ValueError('Provide a JTArmory product detail URL and UPC')
                with connect() as c:c.execute('INSERT OR REPLACE INTO product_pages(upc,url) VALUES(?,?)',(upc,url))
                return self.sendout(output({'ok':True})[1])
            if self.path=='/api/product':
                upc=str(data.get('upc','')).strip();name=str(data['name']).strip();pr=cents(data['price'])
                if not upc:upc='LOCAL-'+uuid.uuid4().hex[:12].upper()
                if not name or len(upc)>80 or len(name)>250 or pr<0:raise ValueError('Invalid product')
                with connect() as c:
                    prior=c.execute('SELECT * FROM products WHERE upc=?',(upc,)).fetchone()
                    if prior and prior['source']=='website':raise ValueError('Website product UPC already exists; choose a different local SKU')
                    c.execute('INSERT OR REPLACE INTO products VALUES(?,?,?,?,?)',(upc,name,pr,'manual',datetime.now().isoformat(timespec='seconds')))
                    audit(c,'product_update' if prior else 'product_created',upc,dict(prior) if prior else None,{'name':name,'price_cents':pr})
                return self.sendout(output({'product':product(upc)})[1])
            if self.path=='/api/sale/item-costs':
                sale_id=int(data.get('id',0))
                values=data.get('costs')
                if not isinstance(values,list):raise ValueError('Provide item costs in an array')
                with connect() as c:
                    c.execute('BEGIN IMMEDIATE')
                    r=c.execute('SELECT items_json,cost_cents,item_costs_json FROM sales WHERE id=?',(sale_id,)).fetchone()
                    if not r:raise ValueError('Sale not found')
                    items=json.loads(r['items_json'])
                    if len(values)!=len(items):raise ValueError('Item cost count does not match sale')
                    clean=[]
                    for value in values:
                        if value is None or str(value).strip()=='':clean.append(None)
                        else:
                            n=cents(value)
                            if n<0 or n>1000000000:raise ValueError('Cost must be between $0 and $10,000,000')
                            clean.append(n)
                    # Store unit costs, multiply by quantities for each line's extended cost.
                    total=sum(v*int(items[i].get('qty',1)) for i,v in enumerate(clean) if v is not None) if all(v is not None for v in clean) else None
                    c.execute('UPDATE sales SET item_costs_json=?,cost_cents=? WHERE id=?',(json.dumps(clean),total,sale_id))
                    audit(c,'sale_item_costs',sale_id,{'cost_cents':r['cost_cents'],'item_costs_json':r['item_costs_json']},{'cost_cents':total,'item_costs_cents':clean})
                return self.sendout(output({'ok':True,'cost_cents':total,'item_costs_cents':clean})[1])
            if self.path=='/api/sale/cost':
                sale_id=int(data.get('id',0))
                raw=data.get('cost')
                if raw is None or str(raw).strip()=='':
                    amount=None
                else:
                    amount=cents(raw)
                    if amount<0 or amount>1000000000:raise ValueError('Cost must be between $0 and $10,000,000')
                with connect() as c:
                    c.execute('BEGIN IMMEDIATE')
                    sale=c.execute('SELECT id,cost_cents,item_costs_json FROM sales WHERE id=?',(sale_id,)).fetchone()
                    if not sale:raise ValueError('Sale not found')
                    c.execute('UPDATE sales SET cost_cents=?,item_costs_json=NULL WHERE id=?',(amount,sale_id))
                    audit(c,'sale_total_cost',sale_id,{'cost_cents':sale['cost_cents'],'item_costs_json':sale['item_costs_json']},{'cost_cents':amount})
                return self.sendout(output({'ok':True,'cost_cents':amount})[1])
            if self.path=='/api/sale':
                clean=clean_items(data.get('items',[]))
                customer=str(data.get('customer','')).strip()[:160]
                method=str(data.get('method','cash'))
                if method not in ('cash','credit','other'):raise ValueError('Invalid method')
                kind=str(data.get('discount_type','none'))
                gift=gift_code(data['gift_code']) if data.get('gift_code') else None
                requested=data.get('gift_cents',0)
                if type(requested)!=int or requested<0:raise ValueError('Invalid gift redemption amount')
                if requested and not gift:raise ValueError('Scan a gift card before redeeming')
                base=totals(clean,False,kind)
                due=base['total_cents']
                if requested>due:raise ValueError('Gift redemption exceeds sale subtotal and tax')
                # Card surcharge, when requested, applies only to the balance charged to credit.
                fee=int((Decimal(due-requested)*Decimal('.03')).quantize(Decimal('1'),rounding=ROUND_HALF_UP)) if bool(data.get('fee')) and method=='credit' else 0
                ts=dict(base,fee_cents=fee,total_cents=due+fee,gift_cents=requested,gift_code=gift,payment_due_cents=due-requested+fee)
                with connect() as c:
                    c.execute('BEGIN IMMEDIATE')
                    if requested:
                        row=c.execute('SELECT balance_cents,status FROM gift_cards WHERE code=?',(gift,)).fetchone()
                        if not row or row['status']!='active':raise ValueError('Gift card not found or inactive')
                        if row['balance_cents']<requested:raise ValueError('Insufficient gift card balance; available '+str(row['balance_cents']/100))
                    cur=c.execute('INSERT INTO sales(timestamp,subtotal_cents,tax_cents,fee_cents,total_cents,method,items_json) VALUES(?,?,?,?,?,?,?)',(
                        datetime.now().isoformat(timespec='seconds'),ts['subtotal_cents'],ts['tax_cents'],fee,ts['total_cents'],method,json.dumps(clean)))
                    ident=cur.lastrowid
                    c.execute('UPDATE sales SET discount_cents=?,discount_type=?,discount_rate=?,customer=?,gift_code=?,gift_cents=? WHERE id=?',
                        (ts['discount_cents'],kind,ts['discount_rate'],customer,gift,requested,ident))
                    if requested:
                        c.execute('UPDATE gift_cards SET balance_cents=balance_cents-?, updated=? WHERE code=?',(requested,datetime.now().isoformat(timespec='seconds'),gift))
                        c.execute('INSERT INTO gift_card_ledger(code,timestamp,delta_cents,event,reference,method) VALUES(?,?,?,?,?,?)',
                            (gift,datetime.now().isoformat(timespec='seconds'),-requested,'redeem',str(ident),'gift'))
                    audit(c,'sale_created',ident,None,{'total_cents':ts['total_cents'],'fee_cents':fee,'method':method,'gift_code':gift,'gift_cents':requested})
                return self.sendout(output({'id':ident,**ts})[1])
            if self.path=='/api/layaway':
                clean=clean_items(data.get('items',[]))
                customer=str(data.get('customer','')).strip()
                contact=str(data.get('contact','')).strip()
                notes=str(data.get('notes','')).strip()
                if not customer or len(customer)>160 or len(contact)>160 or len(notes)>2000:raise ValueError('Customer name required; check field lengths')
                kind=str(data.get('discount_type','none'))
                ts=totals(clean,False,kind)
                deposit=cents(data.get('deposit','0'))
                if deposit<0 or deposit>ts['total_cents']:raise ValueError('Deposit cannot exceed order total')
                method=str(data.get('method','cash'))
                if method not in ('cash','credit','other'):raise ValueError('Invalid payment method')
                now=datetime.now().isoformat(timespec='seconds')
                deposit_fee=int((Decimal(deposit)*Decimal('.03')).quantize(Decimal('1'),rounding=ROUND_HALF_UP)) if method=='credit' and bool(data.get('fee',True)) else 0
                with connect() as c:
                    cur=c.execute("INSERT INTO layaways(created,customer,contact,notes,items_json,discount_type,discount_rate,subtotal_cents,discount_cents,tax_cents,total_cents) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(now,customer,contact,notes,json.dumps(clean),kind,ts['discount_rate'],ts['subtotal_cents'],ts['discount_cents'],ts['tax_cents'],ts['total_cents']))
                    lid=cur.lastrowid
                    if deposit:c.execute('INSERT INTO layaway_payments(layaway_id,paid,amount_cents,method,fee_cents) VALUES(?,?,?,?,?)',(lid,now,deposit,method,deposit_fee))
                    audit(c,'layaway_created',lid,None,{'deposit_cents':deposit,'fee_cents':deposit_fee,'method':method})
                return self.sendout(output({'layaway':layaway_detail(lid)})[1])
            if self.path=='/api/layaway/payment':
                lid=int(data['id']);amount=cents(data['amount']);method=str(data.get('method','cash'))
                if method not in ('cash','credit','other'):raise ValueError('Invalid payment method')
                if amount<=0:raise ValueError('Payment must be greater than $0')
                payment_fee=int((Decimal(amount)*Decimal('.03')).quantize(Decimal('1'),rounding=ROUND_HALF_UP)) if method=='credit' and bool(data.get('fee',True)) else 0
                with connect() as c:
                    c.execute('BEGIN IMMEDIATE')
                    r=c.execute('SELECT total_cents,status FROM layaways WHERE id=?',(lid,)).fetchone()
                    if not r or r['status']!='open':raise ValueError('Layaway not open')
                    paid=c.execute('SELECT COALESCE(SUM(amount_cents),0) FROM layaway_payments WHERE layaway_id=?',(lid,)).fetchone()[0]
                    if amount>r['total_cents']-paid:raise ValueError('Payment exceeds remaining balance')
                    c.execute('INSERT INTO layaway_payments(layaway_id,paid,amount_cents,method,note,fee_cents) VALUES(?,?,?,?,?,?)',
                              (lid,datetime.now().isoformat(timespec='seconds'),amount,method,str(data.get('note',''))[:300],payment_fee))
                    audit(c,'layaway_payment',lid,None,{'payment_cents':amount,'fee_cents':payment_fee,'method':method})
                return self.sendout(output({'layaway':layaway_detail(lid)})[1])
            if self.path=='/api/layaway/close':
                lid=int(data['id'])
                with connect() as c:
                    c.execute('BEGIN IMMEDIATE')
                    r=c.execute('SELECT * FROM layaways WHERE id=?',(lid,)).fetchone()
                    if not r or r['status']!='open':raise ValueError('Layaway not open')
                    paid=c.execute('SELECT COALESCE(SUM(amount_cents),0) FROM layaway_payments WHERE layaway_id=?',(lid,)).fetchone()[0]
                    if paid!=r['total_cents']:raise ValueError('Balance must be paid in full before completion')
                    now=datetime.now().isoformat(timespec='seconds')
                    cur=c.execute('INSERT INTO sales(timestamp,subtotal_cents,tax_cents,fee_cents,total_cents,method,items_json,discount_cents,discount_type,discount_rate,layaway_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)',
                        (now,r['subtotal_cents'],r['tax_cents'],0,r['total_cents'],'layaway',r['items_json'],r['discount_cents'],r['discount_type'],r['discount_rate'],lid))
                    c.execute("UPDATE sales SET customer=? WHERE id=?",(r['customer'],cur.lastrowid))
                    c.execute("UPDATE layaways SET status='completed',closed=? WHERE id=?",(now,lid))
                    audit(c,'layaway_completed',lid,{'status':'open'},{'status':'completed','sale_id':cur.lastrowid})
                return self.sendout(output({'sale_id':cur.lastrowid,'layaway':layaway_detail(lid)})[1])
            if self.path=='/api/layaway/void':
                lid=int(data['id']);reason=str(data.get('reason','')).strip()[:500]
                method=str(data.get('method','other')).strip().lower()
                if not reason:raise ValueError('Reason is required')
                if method not in ('cash','credit','other','none'):raise ValueError('Invalid refund method')
                with connect() as c:
                    c.execute('BEGIN IMMEDIATE')
                    r=c.execute('SELECT status FROM layaways WHERE id=?',(lid,)).fetchone()
                    if not r or r['status']!='open':raise ValueError('Only open layaways can be voided')
                    paid=c.execute('SELECT COALESCE(SUM(amount_cents),0) FROM layaway_payments WHERE layaway_id=?',(lid,)).fetchone()[0]
                    refund=cents(data.get('refund','0'))
                    if refund<0 or refund>paid:raise ValueError('Refund must be between $0 and the amount paid')
                    if refund and method=='none':raise ValueError('Select a refund method')
                    now=datetime.now().isoformat(timespec='seconds')
                    c.execute('INSERT INTO layaway_voids VALUES(?,?,?,?,?)',(lid,now,reason,refund,method))
                    c.execute("UPDATE layaways SET status='voided',closed=? WHERE id=?",(now,lid))
                    audit(c,'layaway_void',lid,{'status':'open'},{'status':'voided','refund_cents':refund,'method':method,'reason':reason})
                return self.sendout(output({'layaway':layaway_detail(lid)})[1])
            if self.path=='/api/sale/void':
                sale_id=int(data.get('id',0))
                reason=str(data.get('reason','')).strip()[:500]
                confirmation=str(data.get('confirmation','')).strip()
                if not reason or len(reason)<5:raise ValueError('Enter a reason (at least 5 characters)')
                if confirmation!=str(sale_id):raise ValueError('Type the sale number to confirm the void')
                # Make an online backup before any destructive/accounting-state change.
                backup_database(force=True)
                with connect() as c:
                    c.execute('BEGIN IMMEDIATE')
                    sale=c.execute('SELECT * FROM sales WHERE id=?',(sale_id,)).fetchone()
                    if not sale:raise ValueError('Sale not found')
                    if c.execute('SELECT 1 FROM sale_voids WHERE sale_id=?',(sale_id,)).fetchone():raise ValueError('This sale was already voided')
                    if sale['layaway_id'] is not None:raise ValueError('Completed layaway sales cannot be voided here; preserve the linked layaway payments')
                    if c.execute('SELECT 1 FROM sale_returns WHERE sale_id=?',(sale_id,)).fetchone():raise ValueError('This sale has recorded returns; a simple void would corrupt refund history')
                    original=dict(sale)
                    now=datetime.now().isoformat(timespec='seconds')
                    if sale['gift_code'] and sale['gift_cents']:
                        code=sale['gift_code'];amt=int(sale['gift_cents'])
                        c.execute('UPDATE gift_cards SET balance_cents=balance_cents+?,updated=? WHERE code=?',(amt,now,code))
                        c.execute('INSERT INTO gift_card_ledger(code,timestamp,delta_cents,event,reference,method,note) VALUES(?,?,?,?,?,?,?)',
                                  (code,now,amt,'sale_void',str(sale_id),'gift','Automatically reversed mistaken sale'))

                    c.execute('INSERT INTO sale_voids(sale_id,voided_at,reason,original_sale_json) VALUES(?,?,?,?)',(sale_id,now,reason,json.dumps(original)))
                    audit(c,'sale_voided',sale_id,original,{'voided_at':now,'reason':reason})
                return self.sendout(output({'ok':True,'sale_id':sale_id,'status':'voided'})[1])
            if self.path=='/api/sale/return':
                sale_id=int(data['id']); reason=str(data.get('reason','')).strip()[:500]
                method=str(data.get('method','other')).strip().lower()
                if not reason:raise ValueError('Enter a return reason')
                requested=data.get('items',[])
                if not isinstance(requested,list) or not requested:raise ValueError('Choose items to return')
                with connect() as c:
                    c.execute('BEGIN IMMEDIATE')
                    sale=c.execute('SELECT * FROM sales WHERE id=?',(sale_id,)).fetchone()
                    if not sale:raise ValueError('Sale not found')
                    if c.execute('SELECT 1 FROM sale_voids WHERE sale_id=?',(sale_id,)).fetchone():raise ValueError('Cannot return a voided sale')
                    method=sale['method']
                    items=json.loads(sale['items_json'])
                    previous=[dict(x) for x in c.execute('SELECT * FROM sale_returns WHERE sale_id=?',(sale_id,))]
                    already={}
                    for pr in previous:
                        for item in json.loads(pr['items_json']):
                            idx=int(item['index']);already[idx]=already.get(idx,0)+int(item['qty'])
                    chosen=[];seen=set()
                    for item in requested:
                        idx=int(item['index']);qty=int(item['qty'])
                        if idx in seen or idx<0 or idx>=len(items) or qty<1:raise ValueError('Invalid return selection')
                        seen.add(idx)
                        if qty>int(items[idx]['qty'])-already.get(idx,0):raise ValueError('Return quantity exceeds unreturned quantity')
                        chosen.append({'index':idx,'qty':qty,'name':items[idx]['name']})
                    # Allocate actual discounted subtotal, tax and card fee using original
                    # line-weight; ensure the final full return equals the actual receipt.
                    weights=[int(x['price_cents'])*int(x['qty']) for x in items]
                    base=sum(weights)
                    if base<=0:raise ValueError('Zero-dollar sale: handle manually')
                    value=sum(int(items[x['index']]['price_cents'])*x['qty'] for x in chosen)
                    prev_amount=sum(x['merchandise_cents'] for x in previous)
                    prev_tax=sum(x['tax_cents'] for x in previous)
                    prev_fee=sum(x['fee_cents'] for x in previous)
                    all_returned=all(already.get(i,0)+next((x['qty'] for x in chosen if x['index']==i),0)==int(it['qty']) for i,it in enumerate(items))
                    merchandise=sale['subtotal_cents']-sale['discount_cents']-prev_amount if all_returned else round((sale['subtotal_cents']-sale['discount_cents'])*value/base)
                    taxable_total=sum(weights[i] for i,x in enumerate(items) if x.get('taxable',True))
                    taxable_requested=sum(int(items[x['index']]['price_cents'])*x['qty'] for x in chosen if items[x['index']].get('taxable',True))
                    tax=sale['tax_cents']-prev_tax if all_returned else round(sale['tax_cents']*taxable_requested/taxable_total) if taxable_total else 0
                    # Surcharges can be refunded by explicit choice, including fees
                    # originally collected over multiple layaway payments.
                    refundable_fee=sale['fee_cents']
                    if sale['layaway_id']:
                        # Surcharge was collected on deposits/payments rather than
                        # during completion. Cap cumulative refunds at collected fees.
                        refundable_fee=c.execute('SELECT COALESCE(SUM(fee_cents),0) FROM layaway_payments WHERE layaway_id=?', (sale['layaway_id'],)).fetchone()[0]
                    fee=(refundable_fee-prev_fee if all_returned else round(refundable_fee*value/base)) if bool(data.get('refund_fee',False)) else 0
                    merchandise=min(merchandise,sale['subtotal_cents']-sale['discount_cents']-prev_amount)
                    tax=min(tax,sale['tax_cents']-prev_tax);fee=min(fee,sale['fee_cents']-prev_fee)
                    refund=merchandise+tax+fee
                    if refund<0:raise ValueError('Invalid refund')
                    if bool(data.get('preview',False)):
                        return self.sendout(output({'preview':True,'merchandise_cents':merchandise,'tax_cents':tax,'fee_cents':fee,'refund_cents':refund,'method':method,'is_layaway':bool(sale['layaway_id'])})[1])
                    # Client passes the exact confirmed refund components; reject stale quotes.
                    if int(data.get('confirmed_refund_cents',-1))!=refund:raise ValueError('Refund quote changed; review again before recording')
                    now=datetime.now().isoformat(timespec='seconds')
                    cur=c.execute('INSERT INTO sale_returns(sale_id,timestamp,items_json,merchandise_cents,tax_cents,fee_cents,refund_cents,method,reason) VALUES(?,?,?,?,?,?,?,?,?)',
                        (sale_id,now,json.dumps(chosen),merchandise,tax,fee,refund,method,reason))
                    audit(c,'sale_return',sale_id,None,{'return_id':cur.lastrowid,'merchandise_cents':merchandise,'tax_cents':tax,'refunded_fee_cents':fee,'refund_cents':refund,'reason':reason,'method':method})
                return self.sendout(output({'return_id':cur.lastrowid,'refund_cents':refund})[1])
            if self.path=='/api/import':
                # JSON rows from browser CSV parser; avoids arbitrary filesystem access
                rows=data.get('rows',[])
                if len(rows)>30000:raise ValueError('Maximum 30,000 rows per import')
                done=0;bad=0
                with connect() as c:
                    for row in rows:
                        try:
                            upc=str(row.get('upc','')).strip(); name=str(row.get('name','')).strip(); price=cents(row['price'])
                            if not upc or not name or price<0:raise ValueError()
                            c.execute('INSERT OR REPLACE INTO products VALUES(?,?,?,?,?)',(upc,name,price,'import',datetime.now().isoformat(timespec='seconds')));done+=1
                        except (ValueError,KeyError,InvalidOperation):bad+=1
                return self.sendout(output({'imported':done,'skipped':bad})[1])
            if self.path=='/api/update/config':
                import updater
                return self.sendout(output({'ok':True,'repository':updater.repo(),'message':'GitHub repository is built in; no configuration required.'})[1])
            if self.path=='/api/update/install':
                import updater
                result=updater.fetch_and_verify()
                flags=subprocess.CREATE_NEW_PROCESS_GROUP|subprocess.DETACHED_PROCESS if os.name=='nt' else 0
                kwargs={'cwd':str(ROOT),'stdout':subprocess.DEVNULL,'stderr':subprocess.DEVNULL}
                if os.name=='nt':kwargs['creationflags']=flags
                else:kwargs['start_new_session']=True
                subprocess.Popen([sys.executable,str(ROOT/'updater.py'),'--install'],**kwargs)
                # Release server port after HTTP response; external installer waits for closure.
                threading.Timer(1.0,lambda:os._exit(0)).start()
                return self.sendout(output({'ok':True,'version':result['version'],'message':'POS is shutting down to apply update. Reopen if it does not restart.'})[1])
            if self.path=='/api/settings':
                url=str(data.get('search_url',''))
                sug=str(data.get('suggestions_url','')).strip()
                parsed=urlparse(sug)
                if not url.startswith(SITE+'/') or '{upc}' not in url:raise ValueError('Search URL must be on https://jtarmory.com/ and contain {upc}')
                if parsed.scheme!='https' or parsed.hostname not in ('jtarmory.com','www.jtarmory.com') or '{upc}' not in sug:raise ValueError('Suggestions URL must be on jtarmory.com and contain {upc}')
                leo=Decimal(str(data.get('leo_discount','0')))
                mil=Decimal(str(data.get('military_discount','0')))
                service=Decimal(str(data.get('service_discount','0')))
                if not (Decimal('0')<=leo<=Decimal('100') and Decimal('0')<=mil<=Decimal('100') and Decimal('0')<=service<=Decimal('100')):raise ValueError('Discount rates must be 0-100%')
                business=data.get('business')
                if not isinstance(business,dict):raise ValueError('Business profile is required')
                clean={}
                for k in BUSINESS_KEYS:
                    val=str(business.get(k,'')).strip()
                    if len(val)>200 or '\n' in val or '\r' in val:raise ValueError('Business profile entries must be one line, up to 200 characters')
                    clean[k]=val
                if not clean['business_name']:raise ValueError('Business name is required')
                if not clean['business_label_name']:raise ValueError('Label name is required')
                with connect() as c:
                    for k,val in clean.items():c.execute('INSERT OR REPLACE INTO settings(k,v) VALUES (?,?)',(k,val))
                    c.execute("INSERT OR REPLACE INTO settings(k,v) VALUES('leo_discount',?)",(str(leo),))
                    c.execute("INSERT OR REPLACE INTO settings(k,v) VALUES('military_discount',?)",(str(mil),))
                    c.execute("INSERT OR REPLACE INTO settings(k,v) VALUES('service_discount',?)",(str(service),))
                    c.execute("UPDATE settings SET v=? WHERE k='search_url'",(url,))
                    c.execute("INSERT OR REPLACE INTO settings(k,v) VALUES('suggestions_url',?)",(sug,))
                return self.sendout(output({'ok':True})[1])
            return self.sendout(output({'error':'Not found'},404)[1],404)
        except Exception as e:return self.sendout(output({'error':str(e)},400)[1],400)
 init()
 return H

if __name__=='__main__':
 init()
 backup_database()
 print('JTArmory POS running at http://127.0.0.1:8765')
 threading.Timer(0.8,lambda:webbrowser.open('http://127.0.0.1:8765')).start()
 ThreadingHTTPServer((HOST,PORT),handler()).serve_forever()
