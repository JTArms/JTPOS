@echo off
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
  py -3 "PREPARE_GITHUB_RELEASE.py"
) else (
  python "PREPARE_GITHUB_RELEASE.py"
)
if errorlevel 1 (
  echo.
  echo ERROR: Could not create the release files. Ensure Python is installed.
  pause
  exit /b 1
)
echo.
echo The output folder should be open in File Explorer.
pause
