JTARMORY POS - Automatic UPC Lookup v3
=====================================
Requires Python 3.10 or later. Unzip and double-click START_POS.bat.
The browser opens on http://127.0.0.1:8765. USB scanners that type a barcode and Enter work with the UPC field.

LIVE LOOKUP
On every website product scan the POS attempts the Gearfire search-suggestions JSON endpoint, uses the returned product and subproduct IDs to assemble the product's detail page URL, then reads that detail page's product structured data to confirm exact UPC and current price.
No website price is hardcoded. It also supports saved product URLs and manually entered items if the website is unavailable.

IMPORTANT: The observed screenshot exposed a request named search-suggestions, but not its FULL REQUEST URL. This package attempts several plausible locations, starting with /api/search-suggestions. If scanning a UPC other than the test item fails, open Chrome DevTools on JTArmory.com, scan the UPC there, click search-suggestions in Network, click Headers, and copy the complete Request URL. In POS Settings, paste it into Gearfire search-suggestions request URL replacing the numeric UPC with {upc}. Then Save Settings and rescan.

The lookup only succeeds when the site allows programmatic requests. The product detail HTML you provided embeds JSON-LD offers pricing (CAT/BEN/A1 $585 at the time copied). Live pricing comes from a new request on each scan, not that saved sample.

The 6% sales tax and optional 3% credit card surcharge are a requested convenience, not legal/tax/processor compliance advice. Verify Maryland taxability and applicable card-network rules, especially for debit and credit card surcharges.

Product and transaction data stay in jtarmory_pos.sqlite3 next to app.py. Always copy that database into the new app folder before launching a replacement version; NEVER overwrite or delete your existing database. Backup with the program closed.

Printing uses the Windows browser's printer dialog. Set paper to 80mm for thermal printers.
This tool is not an ATF compliance system and does not process payments.


VERSION 4: SERVICE DISCOUNTS + LAYAWAYS
-------------------------------------
Settings: choose law enforcement and military discount percentages (default 0%).
At checkout choose the verified customer's category. The POS automatically
reduces the cart price before calculating 6% sales tax. The user must verify
eligibility; it does not identify customers automatically.

Layaways: build a cart, optionally select a discount, then Start Layaway.
Enter customer name/contact, notes and initial deposit. View Layaways tab
for balance and payment history, accept subsequent payments, print a statement.
Once balance reaches zero, choose Mark Complete to record the final sale once.
Deposits are not counted as completed sales until the layaway is marked complete.
Layaway prices/tax/discount are locked at creation; the website's later price
changes will not change an existing layaway.

This basic version does NOT calculate card surcharges on layaway payments,
manage due dates, refund deposits, enforce cancellation policy, reserve inventory
in Gearfire, process payments, or authorize release/transfer of regulated items.
Check your shop policies and Maryland tax rules for when deposits/sales are taxable.
Data is local in jtarmory_pos.sqlite3: back up existing DB before upgrading.

VERSION 5: ONE CHECKBOX + BARCODE-FREE LOCAL CATALOG
--------------------------------------------------
Checkout: tick Apply LEO / Military Discount. Configure the one shared percent
in Settings. No separate category selection. Existing v4 LEO and Military rates
remain in the database for compatibility; v5 uses service_discount instead.
Catalog: click Add Product (No UPC Needed), enter product name and price,
leave UPC empty, and click Save to Catalog. POS generates a LOCAL- identifier.
Catalog entries are saved WITHOUT placing the product in the current cart.
Search product by name or local identifier, then click Edit to change details.
To sell an unbarcoded item, type its generated LOCAL- code into Scan/Enter UPC.
Manual checkout can also save a barcode-free product while adding it to cart.
All data remain on your PC. Preserve your existing SQLite database when upgrading.

V6: Manually created products can be deleted in Product Catalog using the Delete button and confirmation. Website/imported entries cannot be deleted this way. Sales and layaway records remain.

PRODUCT LABELS: In Product Catalog, click Print Label on any manually created product. Prints 3 x 1.15 inch labels with product name, current locally stored price, and a scannable UPC or SKU Code 39 barcode. Set label printer to 3 x 1.15 inches and scale 100%. No extra software required.

EXCEL REPORTS: Requires openpyxl; START_POS.bat attempts to install it automatically.
The downloaded XLSX includes customer, sale details, taxes, credit indicator and blank Cost cells. Enter costs in Excel to calculate profit. Cost edits are not synced back to POS.


VERSION 9: SALES FILTERS, RETURNS, LAYAWAY VOIDS
------------------------------------------------
Sales History -> select Today, This Week (Monday onward), This Quarter, This Year, Custom Dates, or All Time. Search and Excel/CSV exports use the selected range. Sales summary deducts refunds recorded within that date range, even if original sale happened earlier.

Returns: Click Return beside a sale. Enter quantity per item (0 skips), reason, and refund method. The system records negative merchandise, tax and card fee adjustments allocated from the original sale. All changes remain auditable, and cannot exceed quantities sold. RETURNS DO NOT ISSUE MONEY OR RESTOCK INVENTORY. Issue the refund in your merchant terminal and follow required transfer/return rules. Verify taxes and surcharge adjustments.

Layaway void: Open layaway -> Void Layaway / Record Refund. Enter a reason and refund amount up to prior payments; records void status and refund method. LAYAWAY VOID DOES NOT ISSUE MONEY OR RELEASE/RESTOCK INVENTORY. A voided layaway cannot be reopened or completed. Completed layaways remain completed; process a return from the related sale in Sales History instead.

Backup: close POS and copy jtarmory_pos.sqlite3 before updating. This version adds sale_returns and layaway_voids SQL tables; existing sales and products are retained. Retain transaction audit records for accounting. The app is intended for local single-terminal use; it is not payment processing or compliance software.

VERSION 11: RETURN PROFIT CORRECTION
-------------------------------
Returns in Excel now reverse the merchandise sale and the related cost, so a
fully returned sale nets to zero profit after the original cost is entered.
If sale and refund occur in the same exported date range, the return Cost
automatically links to the original Cost cell and is shown as a negative value.
For partial returns, the amount is prorated against refunded after-discount
merchandise revenue. If the original sale is outside the selected export period,
the return Cost cell is yellow for manual NEGATIVE cost entry. Without that
entry, refund profit is blank rather than falsely inflating report profit.
The POS still tracks actual cash refunds separately in net sales totals.

V12: Print Label is now shown for ALL saved catalog products, including Gearfire lookup and CSV-imported products. The barcode encodes the product UPC or SKU; prices reflect the saved catalog entry at time of printing. To refresh a website product price, rescan it before printing. Product deletion remains restricted to manual products.
