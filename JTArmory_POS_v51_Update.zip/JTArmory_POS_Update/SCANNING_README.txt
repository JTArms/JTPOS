SCANNING IN V37
Keep the barcode input focused while scanning. You can scan another barcode while the previous UPC is being looked up; each complete scan (scanner Enter suffix) is queued and looked up one at a time. If a barcode is not found, finish or cancel its manual entry window to resume the pending scans.

IMPORTANT: Back up your existing jtarmory_pos.sqlite3 before updating, and copy it into this folder while the POS is closed. The ZIP does not include a database.
