"""Create a ready-to-publish GitHub Releases ZIP + SHA256 asset."""
from pathlib import Path
import hashlib, json, re, sys, zipfile
ROOT=Path(__file__).resolve().parent
VERSION=int(json.loads((ROOT/'version.json').read_text())['version'])
ALLOWED={'app.py','index.html','START_POS.bat','RESTORE_BACKUP.py','RESTORE_BACKUP.bat','README.txt','CLEAN_INSTALL.txt','PRINT_INSTRUCTIONS.txt','LABEL_PRINT_README.txt','GIFT_CARDS_README.txt','SCANNING_README.txt','UPGRADE_INSTRUCTIONS.txt','BUSINESS_SETUP.txt','VERSION_NOTES.txt','version.json','updater.py','UPDATE_GUIDE.txt','PREPARE_GITHUB_RELEASE.py','PREPARE_GITHUB_RELEASE.bat','AUTO_UPDATE_SETUP.txt'}
output=ROOT.parent/('GitHub_Release_v%d'%VERSION);output.mkdir(exist_ok=True)
name='JTArmory_POS_v%d_Update.zip'%VERSION
with zipfile.ZipFile(output/name,'w',zipfile.ZIP_DEFLATED) as z:
    for f in sorted(ROOT.iterdir()):
        if f.is_file() and f.name in ALLOWED:z.write(f,'JTArmory_POS_Update/'+f.name)
hexdigest=hashlib.sha256((output/name).read_bytes()).hexdigest()
(output/'pos-update.sha256').write_text('%s  %s\n'%(hexdigest,name))
print('Release tag: v%d'%VERSION)
print('Upload both files from:',output)
print('Never upload your database, backups, or update_config.json.')
if sys.platform == 'win32':
    import subprocess
    subprocess.Popen(['explorer.exe', str(output)])
