@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  set "PYCMD=py -3"
) else (
  set "PYCMD=python"
)

echo.
echo [JTArmory POS] Checking GitHub for software updates...
%PYCMD% updater.py --startup
if errorlevel 1 echo [JTArmory POS] Update check encountered a problem; starting installed version.

echo [JTArmory POS] Starting POS...
%PYCMD% -m pip show openpyxl >nul 2>nul || %PYCMD% -m pip install openpyxl
%PYCMD% -m pip show reportlab >nul 2>nul || %PYCMD% -m pip install reportlab
%PYCMD% app.py
pause
