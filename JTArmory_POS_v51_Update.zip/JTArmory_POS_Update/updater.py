"""JTArmory POS GitHub Releases updater, independent of the running webserver.
Requires a GitHub release with an application ZIP and pos-update.sha256.
Updates app assets only. No arbitrary shell commands from releases are executed.
"""
import hashlib, io, json, os, re, shutil, socket, sqlite3, sys, time, urllib.request, zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent
CONFIG=ROOT/'update_config.json'
VERSION=(ROOT/'version.json')
USER_AGENT='JTArmory-POS-Updater/1.0'
MAX_DOWNLOAD=30*1024*1024
SAFE_FILES={'app.py','index.html','START_POS.bat','RESTORE_BACKUP.py','RESTORE_BACKUP.bat','README.txt','CLEAN_INSTALL.txt','PRINT_INSTRUCTIONS.txt','LABEL_PRINT_README.txt','GIFT_CARDS_README.txt','SCANNING_README.txt','UPGRADE_INSTRUCTIONS.txt','BUSINESS_SETUP.txt','VERSION_NOTES.txt','version.json','updater.py','UPDATE_GUIDE.txt','PREPARE_GITHUB_RELEASE.py','AUTO_UPDATE_SETUP.txt'}

def version():
    try:return int(json.loads(VERSION.read_text())['version'])
    except:return 0

# The update source is built into every JTArmory POS installation.
# The local update_config.json is retained for compatibility, but no setup is required.
DEFAULT_REPO = 'JTArms/JTPOS'

def repo():
    return DEFAULT_REPO

def request(url):
    if not url.startswith(('https://api.github.com/','https://github.com/','https://release-assets.githubusercontent.com/','https://objects.githubusercontent.com/')):
        raise ValueError('Unexpected update download host')
    req=urllib.request.Request(url,headers={'User-Agent':USER_AGENT,'Accept':'application/vnd.github+json'})
    with urllib.request.urlopen(req, timeout=8) as r:
        if not r.geturl().startswith('https://'):raise ValueError('Update download is not secure')
        payload=r.read(MAX_DOWNLOAD+1)
        if len(payload)>MAX_DOWNLOAD:raise ValueError('Update file is too large')
        return payload

def available():
    release=json.loads(request('https://api.github.com/repos/'+repo()+'/releases/latest'))
    tag=str(release.get('tag_name',''))
    match=re.fullmatch(r'v(\d+)',tag,re.I)
    if not match:raise ValueError('Latest GitHub release tag must be v49, v50, etc.')
    n=int(match.group(1))
    assets={x['name']:x['browser_download_url'] for x in release.get('assets',[])}
    zipname='JTArmory_POS_v%d_Update.zip'%n
    if zipname not in assets or 'pos-update.sha256' not in assets:
        raise ValueError('Release must contain %s and pos-update.sha256'%zipname)
    return {'current':version(),'latest':n,'tag':tag,'notes':str(release.get('body') or '')[:1800],'zip':zipname,'assets':assets,'update_available':n>version()}

def fetch_and_verify():
    data=available()
    if not data['update_available']:raise ValueError('No newer version is available')
    listing=request(data['assets']['pos-update.sha256']).decode('ascii','strict').strip().splitlines()
    expected=None
    for line in listing:
        parts=line.strip().split()
        if len(parts)==2 and parts[1].lstrip('*')==data['zip'] and re.fullmatch('[a-fA-F0-9]{64}',parts[0]): expected=parts[0].lower()
    if expected is None:raise ValueError('No valid SHA-256 entry for release ZIP')
    archive=request(data['assets'][data['zip']])
    if hashlib.sha256(archive).hexdigest()!=expected:raise ValueError('ZIP SHA-256 verification failed')
    with zipfile.ZipFile(io.BytesIO(archive)) as z:
        names=[x for x in z.namelist() if not x.endswith('/')]
        basenames=[Path(x).name for x in names]
        if len(names)>100 or sum(z.getinfo(x).file_size for x in names)>MAX_DOWNLOAD:raise ValueError('Unexpected release archive contents')
        if basenames.count('app.py')!=1 or basenames.count('index.html')!=1:raise ValueError('Release ZIP must contain app.py and index.html')
        for info in z.infolist():
            path=info.filename.replace('\\','/')
            if path.startswith('/') or '..' in Path(path).parts or (info.external_attr>>16)&0o170000==0o120000:raise ValueError('Unsafe ZIP entry')
            if not info.is_dir() and Path(path).name not in SAFE_FILES:raise ValueError('Unexpected file in update: '+path)
    staged=ROOT/'_update_download.zip'
    staged.write_bytes(archive)
    (ROOT/'_update_ready.json').write_text(json.dumps({'version':data['latest'],'sha256':expected}),encoding='utf-8')
    return {'ready':True,'version':data['latest']}

def safe_backup():
    db=ROOT/'jtarmory_pos.sqlite3'
    if not db.exists():return
    folder=ROOT/'backups';folder.mkdir(exist_ok=True)
    target=folder/('pre_update_'+time.strftime('%Y%m%d_%H%M%S')+'.sqlite3')
    with sqlite3.connect(str(db),timeout=30) as source, sqlite3.connect(str(target)) as backup:
        source.backup(backup)
    with sqlite3.connect(str(target)) as test:
        if test.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise RuntimeError('Database backup failed integrity check')

def wait_port_closed():
    for _ in range(120):
        s=socket.socket();s.settimeout(.3)
        try:r=s.connect_ex(('127.0.0.1',8765))
        finally:s.close()
        if r!=0:return
        time.sleep(.25)
    raise RuntimeError('Close the POS before installing the update')

def install():
    wait_port_closed()
    archive=ROOT/'_update_download.zip'
    metadata=ROOT/'_update_ready.json'
    if not archive.is_file() or not metadata.is_file():raise ValueError('No verified update staged')
    info=json.loads(metadata.read_text())
    if hashlib.sha256(archive.read_bytes()).hexdigest()!=info['sha256']:raise ValueError('Staged release changed')
    if int(info['version'])<=version():raise ValueError('Update is not newer than installed version')
    safe_backup()
    recovery=ROOT/'backups'/('program_before_v%d_%s'%(info['version'],time.strftime('%Y%m%d_%H%M%S')))
    recovery.mkdir(parents=True,exist_ok=True)
    written=[]
    try:
        with zipfile.ZipFile(archive) as z:
            entries={Path(n).name:n for n in z.namelist() if not n.endswith('/') and Path(n).name in SAFE_FILES}
            # Stage application files in backups, to ensure extraction succeeds before replacing live files.
            prepared=recovery/'prepared'; prepared.mkdir()
            for basename,n in entries.items():
                contents=z.read(n)
                (prepared/basename).write_bytes(contents)
            for basename in entries:
                target=ROOT/basename
                if target.is_file():shutil.copy2(target,recovery/basename)
                new=prepared/basename
                os.replace(new,target)
                written.append(basename)
    except Exception:
        for basename in reversed(written):
            old=recovery/basename
            if old.exists():shutil.copy2(old,ROOT/basename)
        raise
    finally:
        archive.unlink(missing_ok=True)
        metadata.unlink(missing_ok=True)
    return int(info['version'])

def startup_update():
    """Check and install BEFORE app.py launches, without blocking offline operation.

    The batch launcher always starts the POS after this command exits.
    Never launch an additional copy of the POS from this startup mode.
    """
    try:
        configured = repo()
    except (ValueError, FileNotFoundError, json.JSONDecodeError):
        print('[Updates] Update server unavailable.')
        return 0

    try:
        result = available()
        if not result['update_available']:
            print('[Updates] JTArmory POS v%d is current.' % result['current'])
            return 0
        print('[Updates] v%d available from %s (installed: v%d).' % (
            result['latest'], configured, result['current']))
        print('[Updates] Downloading and verifying the release...')
        fetch_and_verify()
        print('[Updates] Backing up database and installing...')
        n = install()
        print('[Updates] Installed v%d. Starting updated POS...' % n)
        return 0
    except Exception as exc:
        # Fail open so the shop can work while GitHub, Wi-Fi, or release assets are down.
        try:
            (ROOT/'UPDATE_ERROR.txt').write_text(
                time.strftime('%Y-%m-%d %H:%M:%S') + ': ' + str(exc) + '\n',
                encoding='utf-8')
        except OSError:
            pass
        print('[Updates] Skipped: %s' % exc)
        print('[Updates] Launching the currently installed POS instead.')
        return 0

if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='--startup':
        sys.exit(startup_update())
    if len(sys.argv)>1 and sys.argv[1]=='--install':
        try:
            n=install()
            print('Installed JTArmory POS v%d'%n)
            if os.name=='nt':
                import subprocess
                subprocess.Popen(['cmd','/c','start','""',str(ROOT/'START_POS.bat')],cwd=str(ROOT),creationflags=subprocess.CREATE_NEW_PROCESS_GROUP)
        except Exception as exc:
            (ROOT/'UPDATE_ERROR.txt').write_text(str(exc),encoding='utf-8')
            print('UPDATE FAILED:',exc)
            sys.exit(1)
